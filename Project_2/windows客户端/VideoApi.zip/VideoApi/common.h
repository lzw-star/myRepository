#ifndef COMMON_H
#define COMMON_H

#include"highgui/highgui.hpp"
#include"imgproc/imgproc.hpp"
#include"core/core.hpp"
#include"opencv2\imgproc\types_c.h"

using namespace cv;
#define FRAME_RATE (10)



#endif // COMMON_H
